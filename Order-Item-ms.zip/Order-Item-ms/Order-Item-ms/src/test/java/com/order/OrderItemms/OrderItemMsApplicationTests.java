package com.order.OrderItemms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderItemMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
