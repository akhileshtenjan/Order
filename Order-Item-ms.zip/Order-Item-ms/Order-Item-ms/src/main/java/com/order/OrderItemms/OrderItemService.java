package com.order.OrderItemms;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderItemService {
	
	@Autowired
	private OrderItemRepository orderItemRepository;
	public OrderItem save(OrderItem oi)
	{
		orderItemRepository.save(oi);
		return oi;
	}
	public List<OrderItem> readAll()
	{
		return (List<OrderItem>)orderItemRepository.findAll();
	}
	public OrderItem read(Integer id)
	{
		return orderItemRepository.findById(id).get();
	}
	public OrderItem update(Integer id,OrderItem it)
	{
		OrderItem obj=orderItemRepository.findById(id).get();
		if(obj.getItemName()!=null)
		{
			obj.setItemName(it.getItemName());
		}
		if(obj.getQuantitiy()!=null)
		{
			obj.setQuantitiy(it.getQuantitiy());
		}
		if(obj.getPrice()!=null)
		{
			obj.setPrice(it.getPrice());
		}
		orderItemRepository.save(obj);
		return obj;
	}
	public Integer delete(Integer id)
	{
		 orderItemRepository.deleteById(id);
		 return id;
	}

}
