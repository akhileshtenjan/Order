package com.order.OrderItemms;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderItemMsApplication implements CommandLineRunner {

	@Autowired
	private OrderItemRepository orderItemRepository;
	public static void main(String[] args) {
		SpringApplication.run(OrderItemMsApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		OrderItem oi1=new OrderItem();
		oi1.setItemCode(101);
		oi1.setItemName("Prod1");
		oi1.setQuantitiy(20);
		oi1.setPrice(50.0);
		OrderItem oi2=new OrderItem();
		oi2.setItemCode(102);
		oi2.setItemName("Prod2");
		oi2.setQuantitiy(10);
		oi2.setPrice(60.0);
		OrderItem oi3=new OrderItem();
		oi3.setItemCode(103);
		oi3.setItemName("Prod3");
		oi3.setQuantitiy(20);
		oi3.setPrice(40.0);
		orderItemRepository.saveAll(Arrays.asList(oi1,oi2,oi3));
		
	}

}
