package com.order.OrderItemms;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class OrderItem {
	@Id
	private Integer itemCode;
	private String itemName;
	private Integer quantitiy;
	private Double price;
	

}
