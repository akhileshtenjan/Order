package com.order.OrderItemms;

import java.util.List;

import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/orderitem")
public class OrderItemController {
	
	@Autowired
	private OrderItemService orderItemService;
	@PostMapping
	public OrderItem save(@RequestBody OrderItem oi)
	{
		orderItemService.save(oi);
		return oi;
	}
	@GetMapping
	public List<OrderItem> readAll()
	{
		return (List<OrderItem>)orderItemService.readAll();
	}
	@GetMapping(path = "/{id}")
	public OrderItem read(@PathVariable Integer id)
	{
		return orderItemService.read(id);
	}
	@PostMapping(path = "/{id}")
	public OrderItem update(@PathVariable Integer id,@RequestBody OrderItem oi)
	{
		return orderItemService.update(id, oi);
	}
	@DeleteMapping(path = "/{id}")
	public Integer delete(@PathVariable Integer id)
	{
		 orderItemService.delete(id);
		 return id;
	}

}
 