package com.order.orderms;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/order_item")
public class Order_ItemController {
	
	@Autowired
	private Order_ItemService order_ItemService;
	@PostMapping
	public Order_Item save(@RequestBody Order_Item oi)
	{
		order_ItemService.save(oi);
		return oi;
	}
	@GetMapping
	public List<Order_Item> readAll()
	{
		return (List<Order_Item>)order_ItemService.readAll();
	}
	@GetMapping(path = "/{id}")
	public Order_Item read(@PathVariable Integer id)
	{
		return order_ItemService.read(id);
	}
	@PostMapping(path = "/{id}")
	public Order_Item update(@PathVariable Integer id,@RequestBody Order_Item oi)
	{
		return order_ItemService.update(id, oi);
	}
	@DeleteMapping(path = "/{id}")
	public Integer delete(@PathVariable Integer id)
	{
		order_ItemService.delete(id);
		 return id;
	}

}
