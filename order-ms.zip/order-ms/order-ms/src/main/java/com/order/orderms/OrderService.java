package com.order.orderms;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private Order_itemRepository order_itemRepository;
	
	public Order1 save(Order1 o)
	{
		orderRepository.save(o);
		return o;
	}
	public List<Order1> readAll()
	{
		return (List<Order1>)orderRepository.findAll();
	}
	public Order1 read(Integer id)
	{
		return orderRepository.findById(id).get();
	}
	
	public Order1 update(Integer id,Order1 it)
	{
		Order1 obj=orderRepository.findById(id).get();
		if(obj.getCustomerName()!=null)
		{
			obj.setCustomerName(it.getCustomerName());
		}
		if(obj.getShippingAddress()!=null)
		{
			obj.setShippingAddress(it.getShippingAddress());
		}
		if(obj.getTotal()!=null)
		{
			obj.setTotal(it.getTotal());
		}
		orderRepository.save(obj);
		return obj;
	}
	public Integer delete(Integer id)
	{
		orderRepository.deleteById(id);
		 return id;
	}
	
 
}
