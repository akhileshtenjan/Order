package com.order.orderms;

import org.springframework.data.repository.CrudRepository;

public interface Order_itemRepository extends CrudRepository<Order_Item, Integer> {

}
