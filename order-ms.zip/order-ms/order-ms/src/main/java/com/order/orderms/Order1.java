package com.order.orderms;



import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Order1 {
	@Id
	private Integer customerId;
	private String customerName;
	private String shippingAddress;
	private Double total;
	

}
