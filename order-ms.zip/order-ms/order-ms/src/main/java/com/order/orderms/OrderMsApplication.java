package com.order.orderms;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderMsApplication implements CommandLineRunner {
	
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private Order_itemRepository order_itemRepository;

	public static void main(String[] args) {
		SpringApplication.run(OrderMsApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		Order1 o1=new Order1();
		o1.setCustomerId(1);
		o1.setCustomerName("aaa");
		o1.setShippingAddress("BTM");
		o1.setTotal(500.0);

		Order1 o2=new Order1();
		o2.setCustomerId(2);
		o2.setCustomerName("aaa1");
		o2.setShippingAddress("BTM1");
		o2.setTotal(400.0);
		Order1 o3=new Order1();
		o3.setCustomerId(3);
		o3.setCustomerName("aaa2");
		o3.setShippingAddress("BTM2");
		o3.setTotal(300.0);
		orderRepository.saveAll(Arrays.asList(o1,o2,o3));
		
		
		Order_Item oi1=new Order_Item();
		oi1.setCustomer_id(1);
		oi1.setOrderItem_id(101);
		oi1.setOrderItem_id(102);
		
		Order_Item oi2=new Order_Item();
		oi2.setCustomer_id(2);
		oi2.setOrderItem_id(103);
		
		order_itemRepository.saveAll(Arrays.asList(oi1,oi2));
	
		
		
	}

}
