package com.order.orderms;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
@CrossOrigin
@RequestMapping("/order")
public class OrderController {

	@Autowired
	private OrderService orderService;
	@PostMapping
	public Order1 save(@RequestBody Order1 oi)
	{
		orderService.save(oi);
		return oi;
	}
	@GetMapping
	public List<Order1> readAll()
	{
		return (List<Order1>)orderService.readAll();
	}
	@GetMapping(path = "/{id}")
	public Order1 read(@PathVariable Integer id)
	{
		return orderService.read(id);
	}
	@PostMapping(path = "/{id}")
	public Order1 update(@PathVariable Integer id,@RequestBody Order1 oi)
	{
		return orderService.update(id, oi);
	}
	@DeleteMapping(path = "/{id}")
	public Integer delete(@PathVariable Integer id)
	{
		orderService.delete(id);
		 return id;
	}
}
