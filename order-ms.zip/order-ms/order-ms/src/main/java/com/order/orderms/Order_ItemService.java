package com.order.orderms;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Order_ItemService {
	
	@Autowired
	private Order_itemRepository order_itemRepository;

	
	public Order_Item save(Order_Item o)
	{
		order_itemRepository.save(o);
		return o;
	}
	public List<Order_Item> readAll()
	{
		return (List<Order_Item>)order_itemRepository.findAll();
	}
	public Order_Item read(Integer id)
	{
		return order_itemRepository.findById(id).get();
	}
	
	public Order_Item update(Integer id,Order_Item it)
	{
		Order_Item obj=order_itemRepository.findById(id).get();
		if(obj.getCustomer_id()!=null)
		{
			obj.setCustomer_id(it.getCustomer_id());
		}
		if(obj.getOrderItem_id()!=null)
		{
			obj.setCustomer_id(it.getOrderItem_id());
		}
		
		order_itemRepository.save(obj);
		return obj;
	}
	public Integer delete(Integer id)
	{
		order_itemRepository.deleteById(id);
		 return id;
	}

}
