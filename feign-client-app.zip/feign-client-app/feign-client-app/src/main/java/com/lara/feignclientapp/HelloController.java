package com.lara.feignclientapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	
	@Autowired
	private ProxyForServer proxyForServer;

	@GetMapping(path = "/hello1")
	public String hello1()
	{
		System.out.println("i am from hello1");
		return "i am from hello1"+proxyForServer.callTest1();
	}
}
