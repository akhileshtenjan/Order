package com.lara.feignclientapp;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

//@FeignClient(name = "server-app",url = "http://localhost:8081")
@FeignClient(name = "server-app") //after eureka server
//by using Figenclinet anotation we are making this interface as client to server-app
//by specifying name of server and its url
public interface ProxyForServer {
	@GetMapping(path = "/test1")
	public String callTest1();

}
