package com.lara.serverapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
